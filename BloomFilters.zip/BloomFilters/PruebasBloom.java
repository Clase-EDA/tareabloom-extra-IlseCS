package BloomFilters;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/** 
 * <pre>
 * Clase Pruebas
 * 
 * Clase que contiene los método snecesarios para realizar diferentes pruebas
 * con BloomFilters.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class PruebasBloom {
    
    //para ingresar datos
    public static void lectura (int num, int i, String [] palabras){
        //para ingresar los datos del archivo de texto
        try {
            FileReader inputFile = new FileReader("palabras.txt");
            try {
                Scanner parser = new Scanner(inputFile);
                while (parser.hasNextLine() && i<num){
                    //leer
                    String line = parser.nextLine();
                    //insertar
                    palabras[i]=line;
                    i++;
                }//cierre while
            }//cierre primer try
            finally {
                inputFile.close();
            }//cierre finally
        } catch(FileNotFoundException exception) {
            System.out.println("palabras.txt" + " not found");
        } catch(IOException exception){
	System.out.println("Unexpected I/O error occured.");
        }//cierre segundo catch
    }//end lectura
    
    //para meter datos al trie
    public static void inserta(BloomFilter bloom, String [] palabras){
        //para pasar los datos del arreglo al trie y ordenar
        for (int i=0;i<palabras.length;i++){
            bloom.agrega(palabras[i]);
        }//cierre del for
    }//end ordena
   
//----------------------------- INICIO MAIN ------------------------------------
 
    public static void main(String[] args) {
        
        //aux
        int num=1000;
        double p = 0.1;
        //declaración del bloom
        BloomFilter <String> bloom = new BloomFilter(1000, p);
        
        //para insertar las palabras 
        String [] palabras = new String [num];
        lectura(num, 0, palabras);
        inserta (bloom, palabras);
        
        //número de espacios mínimos
        System.out.println("Número de espacios mínimos: ");
        System.out.println(GeneraBloom.calculaM(num, p));
        
        //número de funciones de hash
        System.out.println("Número de funciones de hash: ");
        System.out.println(GeneraBloom.calculaK(num, p ));
        
        //Porcentaje de falsos positivos
        System.out.println("Porcentaje de falsos positivos: ");
        System.out.println(p);
        
        //máximo de objetos a ingresar
        System.out.println("Máximo de objetos a ingresar: " + bloom.getN() + "\n");
        
        System.out.println("\n -------------------------------------");
        //aux
        p = 0.01;
        //declaración del bloom
        BloomFilter <String> bloom2 = new BloomFilter(1000, p);
        
        //para insertar las palabras 
        String [] palabras2 = new String [num];
        lectura(num, 0, palabras);
        inserta (bloom, palabras);
        
        //número de espacios mínimos
        System.out.println("Número de espacios mínimos: ");
        System.out.println(GeneraBloom.calculaM(num, p));
        
        //número de funciones de hash
        System.out.println("Número de funciones de hash: ");
        System.out.println(GeneraBloom.calculaK(num, p ));
        
        //Porcentaje de falsos positivos
        System.out.println("Porcentaje de falsos positivos: ");
        System.out.println(p);
        
        //máximo de objetos a ingresar
        System.out.println("Máximo de objetos a ingresar: " + bloom2.getN() + "\n");
        
        System.out.println("\n -------------------------------------");
        //aux
        p = 0.001;
        //declaración del bloom
        BloomFilter <String> bloom3 = new BloomFilter(1000, p);
        
        //para insertar las palabras 
        String [] palabras3 = new String [num];
        lectura(num, 0, palabras);
        inserta (bloom, palabras);
        
        //número de espacios mínimos
        System.out.println("Número de espacios mínimos: ");
        System.out.println(GeneraBloom.calculaM(num, p));
        
        //número de funciones de hash
        System.out.println("Número de funciones de hash: ");
        System.out.println(GeneraBloom.calculaK(num, p ));
        
        //Porcentaje de falsos positivos
        System.out.println("Porcentaje de falsos positivos: ");
        System.out.println(p);
        
        //máximo de objetos a ingresar
        System.out.println("Máximo de objetos a ingresar: " + bloom3.getN() + "\n");
        
        System.out.println("\n -------------------------------------");
        //aux
        p = 0.0001;
        //declaración del bloom
        BloomFilter <String> bloom4 = new BloomFilter(1000, p);
        
        //para insertar las palabras 
        String [] palabras4 = new String [num];
        lectura(num, 0, palabras);
        inserta (bloom, palabras);
        
        //número de espacios mínimos
        System.out.println("Número de espacios mínimos: ");
        System.out.println(GeneraBloom.calculaM(num, p));
        
        //número de funciones de hash
        System.out.println("Número de funciones de hash: ");
        System.out.println(GeneraBloom.calculaK(num, p ));
        
        //Porcentaje de falsos positivos
        System.out.println("Porcentaje de falsos positivos: ");
        System.out.println(p);
        
        //máximo de objetos a ingresar
        System.out.println("Máximo de objetos a ingresar: " + bloom4.getN() + "\n");
    }//end main
    
    
        
        
}//end class
