package BloomFilters;

import Tries.*;

/** 
 * <pre>
 * Clase EmptyCollectionException
 * 
 * Clase auxiliar que arroja mensajes de error para indicar que diferentes
 * colecciones se encuentran vacías.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class EmptyCollectionException extends RuntimeException {
    
    //constructor
    public EmptyCollectionException (){
        super ("Colección vacía");
    }
    
    //constructor
    public EmptyCollectionException (String mensaje) {
        super(mensaje);
    }
    
}//end EmptyCollectionException
