package BloomFilters;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.BitSet;

/** 
 * <pre>
 * Clase GeneraBloom
 * 
 * Clase que contiene los métodos necesarios para insertar, buscar
 * y verificar si un elemento está contenido en un BloomFilter.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class BloomFilter <T>{
    /* un BitSet genera un arreglo de bits
     * representado por valores booleanos.*/
    private BitSet set;
    //tamaño del arreglo 
    private int m; 
    //número de elementos a insertar
    private int n;
    //numero de elementos en el BloomFilter
    private int count;
    //número de funciones de hash 
    private int k;
    /* MessageDigest es una función de
     * hash criptográfica */
    static MessageDigest md;
    //para definir el mapeo de secuencias a UTF-8
    static final Charset encoding = Charset.forName("UTF-8"); 
    
    //Constructor
    public BloomFilter (int numElem, double porcentajeE){
        //calcular tamaño del arreglo 
        this.m = GeneraBloom.calculaM(numElem,porcentajeE);
        this.n = numElem;
        this.count = 0;
        //calcular el número de funciones de hash necesarias
        this.k = GeneraBloom.calculaM(numElem,porcentajeE);
        // para establecer el tamaño del arreglo 
        this.set = new BitSet(m);
        //para verificar que se encuentre MD5
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException("Error : MD5 Hash not found");
        }//end catch
    }//end constructor
    
//---------------------------------- SECCIÓN GETS ------------------------------
    
    //regresa tamaño del arreglo
    public int getM() {
        return this.m;
    }
    
    //regresar máximo número de elementos
    public int getN(){
        return this.n;
    }

    //regresa número de elementos almacenados en el BloomFilter
    public int getNumElem () {
        return this.count;
    }
    
    //regresa número de funciones de hash
    public int getK() {
        return this.k;
    }

//---------------------------- SECCIÓN CLEAR -----------------------------------
    
    //método para eliminar todos los elementos de un BloomFilter
    public void clearAll (){
        //pone todos los valores del BloomFilter en false
        set.clear();
        count = 0;
    }//end clear
  
//----------------------------- SECCIÓN ADD ------------------------------------
 
    //método público para agregar elementos al BloomFilter
    public void agrega (T element) {
        //verificar que elemento no sea nulo
        if (element != null){
            /* 1) llamar a método auxiliar
             * 2) convertir elemento a String
             * 3) codificar String a secuencia de bytes
             * utilizando UTF - 8 */
            byte [] aux = element.toString().getBytes(encoding);
            //llamar a método auxiliar 
            agrega(aux);
        } else
            throw new EmptyCollectionException ("\n Elemento vacío");
    }//end add público
    
    //método privado para agregar elementos al BloomFilter
    private void agrega(byte[] aux) {
       //arreglo donde se guardarán las funciones de hash
       int[] hashes = generaHash(aux, k);
       //enhanced for para recorrer arreglo de hashes
       for (int hash : hashes)
          /* 1) pasar los bytes por las funciones de hash
           * generadas con el método auxiliar. Se hace 
           * módulo m para que los valores obtenidos puedan
           * marcarse dentro del arreglo.
           * 2) marcar como true los valores obtenidos 
           * después de pasar los bytes por las funciones
           * de hash. */
           set.set(Math.abs(hash % m), true);
       //aumentar número de elementos en el arreglo 
       count ++;
    }// end agrega privado  
    
    //método auxiliar para generar las funciones de hash
    private int[] generaHash(byte[] aux, int numHashes) {
        /* crear un arreglo con el espacio del número de funciones 
         * de has necesarias (k). */
        int[] funciones = new int[numHashes];
        //auxiliares para el ciclo 
        int k = 0;
        byte cont = 0;
        //para generar el número de funciones de hash necesarias 
        while (k < numHashes) {
            byte[] digest;
            //se utiliza para evitar un thread condition
            synchronized (md) {
                //para update el messageDigest usando el bit seleccionado
                md.update(cont);
                cont++;
                // para completar la función de hash
                digest = md.digest(aux);                
            } //cierre del synchronized
            for (int i=0; i< digest.length/4 && k<numHashes; i++) {
                int h = 0;
                // para dividir el resultado en enteros de 4 bytes
                for (int j=(i*4); j<(i*4)+4; j++) {
                    h <<= 8;
                    //agregar y cast a int (utilizar 0xFF para formato 00 00 ff)
                    h |= ((int) digest[j]) & 0xFF;
                }//cierre for interno
                //insertar en arreglo
                funciones[k] = h;
                //aumentar cont aux 
                k++;
            }//cierre del for
        }//cierre del while 
        return funciones;
    }// end generaHash
    
 //------------------------- SECCIÓN CONTAINS ----------------------------------
    
    //método público para verificar si un elemento se encuentra en el BloomFilter
    public boolean contains(T element) {
        //verificar que elemento no sea nulo
        if (element != null){
            /* 1) llamar a método auxiliar
             * 2) convertir elemento a String
             * 3) codificar String a secuencia de bytes
             * utilizando UTF - 8 */
            byte [] aux = element.toString().getBytes(encoding);
            //llamar a método auxiliar 
        return contains(aux);
        } else
            throw new EmptyCollectionException("\nElemento nulo");
    }// end contains público
        
    //método privado para verificar si un elemento se encuentra en el BloomFilter
    private boolean contains(byte[] bytes) {
        //arreglo donde se guardan las funciones de hash
        int[] hashes = generaHash(bytes, k);
        //enhanced for para recorrer arreglo de hashes
        for (int hash : hashes) {
            //verificar si se encuentra el valor
            if (!set.get(Math.abs(hash % m))) 
                return false;
        }//cierre del for
        return true;
    }//end contains privado
    
//----------------------------- INICIO MAIN ------------------------------------
    
    public static void main(String[] args) {
        
//        //construir BloomFilter
//        BloomFilter <String> bloom = new BloomFilter(1000, 0.0001);
//        
//        //número de espacios mínimos
//        System.out.println("Número de espacios mínimos: ");
//        System.out.println(GeneraBloom.calculaM(1000, 0.0001));
//        
//        //número de funciones de hash
//        System.out.println("Número de funciones de hash: ");
//        System.out.println(GeneraBloom.calculaK(1000, 0.0001));
//        
//        //máximo de objetos a ingresar
//        System.out.println("Máximo de objetos a ingresar: " + bloom.getN() + "\n");
//        
//        //prueba agregar datos
//        bloom.agrega("runyu");
//        bloom.agrega("xuefang");
//        bloom.agrega("jinmi");
//        bloom.agrega("dianxia");
//        bloom.agrega("hexuan");
//        bloom.agrega("mingyi");
//        bloom.agrega("quingxuan");
//        bloom.agrega("junwu");
//        bloom.agrega("fengxin");
//        bloom.agrega("muqing");
//        bloom.agrega("peiming");
//        bloom.agrega("xielian");
//        
//        System.out.println("Número de elementos en el bloom: " + bloom.getNumElem());
//        
//        //prueba contains
//        System.out.println(bloom.contains("mingyi")); //true
//        System.out.println(bloom.contains("runyu")); //true
//        System.out.println(bloom.contains("xielian")); //true
//        System.out.println(bloom.contains("jinmi")); //true
//        System.out.println(bloom.contains("dianxia")); //true
//        System.out.println(bloom.contains("sanlang")); //true *
//        System.out.println(bloom.contains("ruoye")); //true *
//        System.out.println(bloom.contains("peiming")); //true
//        System.out.println(bloom.contains("fengxin")); //true
//        System.out.println(bloom.contains("ana")); //false
    }//end main
}//end class