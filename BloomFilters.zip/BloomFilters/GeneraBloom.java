package BloomFilters;

/** 
 * <pre>
 * Clase GeneraBloom
 * 
 * Clase que contiene los métodos necesarios para que dado una n 
 * (número de elementos a almacenar) y una f (porcentaje de falsos
 * positivos aceptados), se determine el tamaño mínimo de m (número
 * de bits para almacenar) y k (número de funciones de hash necesarias).
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class GeneraBloom {
    
    /*
     * método para determinar el tamaño mínimo de n. Se utiliza la 
     * siguiente fórmula: m = -n*ln(f) / (ln(2)^2)
     *
     * @param int n - número de datos por almacenar
     * @param double f - porcentaje de falsos positivos aceptados
     */
    public static int calculaM (int n, double f){
        double m;
        //-n*ln(f)
        double aux = Double.valueOf(n) * -1 * Math.log(f);
        //(ln(2)^2)
        double aux2 = Math.pow(Math.log(2), 2);
        //m = -n*ln(f) / (ln(2)^2)
        m = aux / aux2;
        //pasar a enteros
        int resp = (int)m;
        return resp;
    }//end calculaM
    
    /*
     * método para determinar el número de k necesarias. Se utiliza la 
     * siguiente fórmula: k = m/n * ln(2)
     *
     * @param int n - número de datos por almacenar
     * @param double f - porcentaje de falsos positivos aceptados
     */
    public static int calculaK (int n, double f){
        double k;
        //para calcular m (número de bits)
        int m = calculaM(n,f);
        //k = m/n * ln(2)
        k = m/n * Math.log(2);
        //pasar a enteros
        int resp = (int)k;
        //verificar que se utilice mínimo una función de hash
        if (resp <= 0)
            resp = 1;
        return resp;
    }//end calculaF

//---------------------------------- INICIO MAIN -------------------------------
    public static void main(String[] args) {
        //auxiliares para pruebas
        int n = 216553;
        double f = 0.01;
        
        //prueba calculaM - OK
        System.out.println(calculaM(n,f));
        
        //prueba calculaF 
        System.out.println(calculaK(n,f));
    }//end main
}//end class
